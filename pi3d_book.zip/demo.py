import sys
sys.path.insert(1, '/home/jill/pi3d')

